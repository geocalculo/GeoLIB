// js/mapainfo.js (modular + UX móvil + PDF cliente ULTRA-ROBUSTO)
// Requiere: <script type="module" src="js/mapainfo.js"></script>

import { loadProyectosXlsx } from "./core/dataLoader.js";
import { runProximityEngine } from "./features/proximity/proximityEngine.js";
import { buildReportModel } from "./report/reportModel.js";
import { createMapLayers } from "./ui/mapLayers.js";
import { createProjectsPanel } from "./ui/panel.js";
import { updateCharts } from "./ui/chartsController.js";
import { downloadProximityKMZ } from "./export/kmzExport.js";

import { getMapainfoParamsFromUrl } from "./app/router.js";
import { renderInfoBar } from "./ui/infoBar.js";
import { bindKmzButton } from "./ui/actions.js";

// -------------------
// Config
// -------------------
const DATA_XLSX_URL = "capas/nacional.xlsx";

// -------------------
// State
// -------------------
let map = null;
let mapLayers = null;
let panel = null;
let model = null;

// -------------------
// Helpers
// -------------------
function isMobile() {
  return window.matchMedia("(max-width: 768px)").matches;
}

function readBasemapPrefs() {
  try {
    const raw = localStorage.getItem("geoeva_basemap");
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

/**
 * Política UX móvil:
 * - 1 dedo: NO arrastra el mapa (la página scrollea)
 * - 2 dedos: pinch zoom + (opcional) pan con 2 dedos
 */
function enableTwoFingerZoomOnly(map) {
  if (!map || !isMobile()) return;

  if (map._twoFingerEnabled) return;
  map._twoFingerEnabled = true;

  map.dragging.disable();
  map.touchZoom.enable();
  map.doubleClickZoom.disable();
  map.scrollWheelZoom.disable();
  map.boxZoom.disable();
  map.keyboard.disable();

  if (map.tap) map.tap.enable();

  const container = map.getContainer();
  container.style.touchAction = "pan-y";

  container.addEventListener(
    "touchmove",
    (e) => {
      if (e.touches && e.touches.length >= 2) e.preventDefault();
    },
    { passive: false }
  );

  container.addEventListener(
    "touchstart",
    (e) => {
      if (e.touches && e.touches.length >= 2) map.dragging.enable();
      else map.dragging.disable();
    },
    { passive: true }
  );

  container.addEventListener(
    "touchend",
    () => map.dragging.disable(),
    { passive: true }
  );
}

// -------------------
// Mobile bottom sheet
// -------------------
function initMobileSheet() {
  const sheet = document.getElementById("mobileSheet");
  const backdrop = document.getElementById("mobileSheetBackdrop");
  const btnClose = document.getElementById("msClose");
  const handle = document.getElementById("mobileSheetHandle");

  if (!sheet || !backdrop) return;

  function close() {
    sheet.classList.add("hidden");
    backdrop.classList.add("hidden");
    sheet.setAttribute("aria-hidden", "true");
    backdrop.setAttribute("aria-hidden", "true");
  }

  function open() {
    sheet.classList.remove("hidden");
    backdrop.classList.remove("hidden");
    sheet.setAttribute("aria-hidden", "false");
    backdrop.setAttribute("aria-hidden", "false");
  }

  backdrop.addEventListener("click", close);
  btnClose?.addEventListener("click", close);
  handle?.addEventListener("click", close);

  window.__openMobileSheet = open;
  window.__closeMobileSheet = close;
}

function openMobileSheet(p) {
  if (!isMobile()) return;

  const title = document.getElementById("msTitle");
  const meta = document.getElementById("msMeta");
  const exp = document.getElementById("msExp");
  const anx = document.getElementById("msAnx");

  if (!title || !meta || !exp || !anx) return;

  title.textContent = p?.nombre || "Proyecto";

  const dist = Number.isFinite(p?.distKm) ? `${p.distKm.toFixed(2)} km` : "—";
  meta.innerHTML = `
    <div><b>Distancia:</b> ${dist}</div>
    <div><b>Estado:</b> ${escapeHtml(p?.estado || "—")}</div>
    <div><b>Sector:</b> ${escapeHtml(p?.sector || "—")}</div>
  `;

  const expUrl = (p?.web || "").trim();
  const anxUrl = (p?.anexos || "").trim();

  if (expUrl) {
    exp.href = expUrl;
    exp.style.opacity = "1";
    exp.style.pointerEvents = "auto";
  } else {
    exp.href = "#";
    exp.style.opacity = "0.5";
    exp.style.pointerEvents = "none";
  }

  if (anxUrl) {
    anx.href = anxUrl;
    anx.style.opacity = "1";
    anx.style.pointerEvents = "auto";
  } else {
    anx.href = "#";
    anx.style.opacity = "0.5";
    anx.style.pointerEvents = "none";
  }

  window.__openMobileSheet?.();
}

// Exponer API para otros módulos (mapLayers)
window.openMobileSheet = openMobileSheet;
window.__isMobile = isMobile;

// -------------------
// Map init
// -------------------
function initMap({ lat, lng }) {
  map = L.map("map", { center: [lat, lng], zoom: 11, minZoom: 4, zoomControl: true });
  window.__leafletMap = map;

  enableTwoFingerZoomOnly(map);

  const prefs = readBasemapPrefs() || {
    addOSM: true,
    osmOpacity: 1.0,
    addIMG: true,
    imgOpacity: 0.1,
  };

  const osm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    opacity: Math.max(0, Math.min(1, Number(prefs.osmOpacity ?? 1))),
    attribution: "&copy; OpenStreetMap contributors",
  });

  const img = L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    { maxZoom: 19, opacity: Math.max(0, Math.min(1, Number(prefs.imgOpacity ?? 0.1))) }
  );

  if (prefs.addOSM !== false) osm.addTo(map);
  if (prefs.addIMG !== false) img.addTo(map);

  L.control.scale().addTo(map);

  mapLayers = createMapLayers(map);
  setTimeout(() => map.invalidateSize(), 150);
}

// -------------------
// PDF cliente (ULTRA-ROBUSTO con debugging)
// -------------------
function buildReportHTML({ params, resumen, proyectos }) {
  const rows = proyectos
    .map(
      (p, i) => `
    <tr style="page-break-inside: avoid;">
      <td style="padding:6px;border-bottom:1px solid #eee;">${i + 1}</td>
      <td style="padding:6px;border-bottom:1px solid #eee;">${escapeHtml(p.nombre || "")}</td>
      <td style="padding:6px;border-bottom:1px solid #eee;">${escapeHtml(p.estado || "")}</td>
      <td style="padding:6px;border-bottom:1px solid #eee;">${escapeHtml(p.sector || "")}</td>
      <td style="padding:6px;border-bottom:1px solid #eee;">${escapeHtml(p.region || "")}</td>
      <td style="padding:6px;border-bottom:1px solid #eee;text-align:right;">${
        Number.isFinite(p.distKm) ? p.distKm.toFixed(2) : "—"
      } km</td>
    </tr>
  `
    )
    .join("");

  return `
  <div style="font-family: Arial, sans-serif; font-size: 12px; color:#111; line-height: 1.4;">
    <h1 style="margin:0 0 6px; font-size: 18px; color: #000;">GeoEVA – Informe de Proximidad</h1>

    <div style="margin:0 0 12px; color:#444; font-size: 11px;">
      <strong>Punto:</strong> ${Number(params.lat).toFixed(6)}, ${Number(params.lng).toFixed(6)}<br/>
      <strong>Modo:</strong> ${escapeHtml(params.modo)} · <strong>Radio:</strong> ${Number(params.radio).toFixed(2)} km · <strong>N:</strong> ${escapeHtml(String(params.n))}<br/>
      <strong>Resumen:</strong> ${escapeHtml(resumen.texto || "Sin datos")}<br/>
      <strong>Inversión:</strong> ${escapeHtml(resumen.inversion || "Sin datos")}
    </div>

    <h2 style="margin:14px 0 8px; font-size:14px; color: #000;">Proyectos Encontrados</h2>
    <table style="width:100%; border-collapse: collapse; font-size: 10px;">
      <thead>
        <tr style="background: #f0f0f0;">
          <th style="border: 1px solid #ccc; text-align:left; padding:6px;">#</th>
          <th style="border: 1px solid #ccc; text-align:left; padding:6px;">Proyecto</th>
          <th style="border: 1px solid #ccc; text-align:left; padding:6px;">Estado</th>
          <th style="border: 1px solid #ccc; text-align:left; padding:6px;">Sector</th>
          <th style="border: 1px solid #ccc; text-align:left; padding:6px;">Región</th>
          <th style="border: 1px solid #ccc; text-align:right; padding:6px;">Dist.</th>
        </tr>
      </thead>
      <tbody>
        ${rows}
      </tbody>
    </table>

    <div style="margin-top:16px; font-size:9px; color:#999;">
      Generado en el navegador – ${new Date().toLocaleString("es-CL")}
    </div>
  </div>`;
}

async function downloadPDFClient({ params, resumen, proyectos }) {
  console.log('🔵 [PDF] Iniciando generación...');
  
  if (!window.html2pdf) {
    throw new Error("html2pdf no está cargado");
  }

  if (!params || typeof params !== 'object') {
    throw new Error('params es requerido');
  }
  if (!resumen || typeof resumen !== 'object') {
    throw new Error('resumen es requerido');
  }
  if (!Array.isArray(proyectos)) {
    throw new Error('proyectos debe ser un array');
  }

  console.log('🔵 [PDF] Construyendo HTML...', { proyectos: proyectos.length });
  const html = buildReportHTML({ params, resumen, proyectos });
  console.log('🔵 [PDF] HTML generado:', html.substring(0, 200) + '...');

  // ===== ESTRATEGIA ULTRA-ROBUSTA =====
  const holder = document.createElement("div");
  holder.id = `pdf-holder-${Date.now()}`;

  // ✅ FORZAR ESTILOS CON cssText (más fuerte que Object.assign)
  holder.style.cssText = `
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 210mm !important;
    min-height: 297mm !important;
    padding: 15mm !important;
    margin: 0 !important;
    background: white !important;
    box-sizing: border-box !important;
    opacity: 0.01 !important;
    z-index: -10000 !important;
    pointer-events: none !important;
    overflow: visible !important;
    transform: none !important;
    will-change: auto !important;
    display: block !important;
    visibility: visible !important;
    font-family: Arial, sans-serif !important;
    color: #000 !important;
  `;

  holder.innerHTML = html;
  
  console.log('🔵 [PDF] Inyectando holder en body...');
  document.body.appendChild(holder);

  // ✅ FORZAR REFLOW MÚLTIPLE
  void holder.offsetHeight;
  void holder.offsetWidth;
  void holder.clientHeight;
  
  console.log('🔵 [PDF] Esperando frames...');
  await new Promise(r => requestAnimationFrame(() =>
    requestAnimationFrame(() => 
      requestAnimationFrame(r) // 3 frames en vez de 2
    )
  ));

  if (document.fonts) {
    console.log('🔵 [PDF] Esperando webfonts...');
    await document.fonts.ready;
  }

  const images = holder.querySelectorAll('img');
  if (images.length > 0) {
    console.log(`🔵 [PDF] Esperando ${images.length} imágenes...`);
    await Promise.all(
      Array.from(images).map(img => {
        if (img.complete) return Promise.resolve();
        return new Promise(resolve => {
          img.onload = resolve;
          img.onerror = resolve;
          setTimeout(resolve, 5000);
        });
      })
    );
  }

  // ✅ ESPERA LARGA (200ms en vez de 50ms)
  console.log('🔵 [PDF] Espera de seguridad...');
  await new Promise(r => setTimeout(r, 200));

  // ===== VALIDACIÓN EXHAUSTIVA =====
  const rect = holder.getBoundingClientRect();
  console.log('🔵 [PDF] Dimensiones del holder:', {
    width: rect.width,
    height: rect.height,
    top: rect.top,
    left: rect.left
  });

  const computed = window.getComputedStyle(holder);
  console.log('🔵 [PDF] Computed styles:', {
    display: computed.display,
    visibility: computed.visibility,
    opacity: computed.opacity,
    position: computed.position,
    width: computed.width,
    height: computed.height,
    zIndex: computed.zIndex
  });

  if (rect.width === 0 || rect.height === 0) {
    console.error("❌ [PDF] Holder sin dimensiones:", rect);
    console.error("HTML del holder:", holder.innerHTML.substring(0, 1000));
    
    // ✅ DEBUG: Hacer visible temporalmente
    holder.style.opacity = '1';
    holder.style.zIndex = '999999';
    alert('ERROR: Holder no tiene dimensiones. Revisa la consola y el holder (ahora visible en pantalla).');
    throw new Error("Holder no renderizado - ver consola");
  }

  console.log('✅ [PDF] Holder válido, procediendo a captura...');

  const isDev = window.location.hostname === 'localhost' || 
                window.location.hostname.includes('127.0.0.1') ||
                window.location.hostname.includes('192.168');

  try {
    console.log('🔵 [PDF] Llamando a html2pdf...');
    
    const opt = {
      margin: 0,
      filename: `GeoEVA_informe_${Date.now()}.pdf`,
      image: { 
        type: "jpeg", 
        quality: 0.98 
      },
      html2canvas: {
        scale: 2,
        useCORS: true,
        allowTaint: false,
        backgroundColor: "#ffffff",
        logging: true, // ✅ SIEMPRE activado para debug
        letterRendering: true,
        removeContainer: false,
        scrollY: 0,
        scrollX: 0,
        windowWidth: holder.scrollWidth,
        windowHeight: holder.scrollHeight,
        foreignObjectRendering: false,
        // ✅ FORZAR CAPTURA SINCRONA
        async: false,
        width: holder.scrollWidth,
        height: holder.scrollHeight
      },
      jsPDF: {
        unit: "mm",
        format: "a4",
        orientation: "portrait",
        compress: true
      },
      pagebreak: { mode: ["avoid-all", "css", "legacy"] }
    };

    console.log('🔵 [PDF] Opciones:', JSON.stringify(opt, null, 2));

    await window.html2pdf()
      .set(opt)
      .from(holder)
      .save();
      
    console.log('✅ [PDF] PDF generado exitosamente');
    
  } catch (error) {
    console.error('❌ [PDF] Error en html2pdf:', error);
    console.error('Stack:', error.stack);
    
    // ✅ DEBUG: Hacer visible para inspección
    holder.style.opacity = '1';
    holder.style.zIndex = '999999';
    alert(`ERROR generando PDF: ${error.message}\n\nHolder ahora visible en pantalla para inspección.`);
    
    throw error;
  } finally {
    // ✅ NO limpiar inmediatamente si hubo error (para debug)
    if (!holder.style.zIndex.includes('999999')) {
      holder.remove();
      console.log('🧹 [PDF] Holder limpiado');
    } else {
      console.warn('⚠️ [PDF] Holder dejado visible para debug');
    }
  }
}


function bindPdfButtonOnce() {
  const btn = document.getElementById("btnPdf");
  
  if (!btn) {
    console.warn('⚠️ Botón #btnPdf no encontrado');
    return;
  }

  if (btn.dataset.bound === "1") {
    console.log('ℹ️ Botón PDF ya vinculado');
    return;
  }
  
  btn.dataset.bound = "1";
  console.log('✅ Botón PDF vinculado');

  btn.addEventListener("click", async () => {
    try {
      if (!model) {
        alert("Aún no termina de cargar la data (espera 1-2 segundos).");
        return;
      }

      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "⏳ Generando PDF...";
      btn.style.opacity = "0.6";
      btn.style.cursor = "wait";

      const resumenTexto = document.getElementById("countLabel")?.textContent || "";
      const invTexto = document.getElementById("invLabel")?.textContent || "";

      const radio = Number(
        model?.query?.radioKmFinal ??
        model?.query?.radioKm ??
        model?.query?.radio ??
        NaN
      );

      const payload = {
        params: {
          lat: model.query.lat,
          lng: model.query.lng,
          radio: Number.isFinite(radio) ? radio : 0,
          modo: model.query.modo,
          n: model.query.n ?? (model.projects?.length ?? 0),
        },
        resumen: { texto: resumenTexto, inversion: invTexto },
        proyectos: Array.isArray(model.projects) ? model.projects : [],
      };

      console.log('🔵 Payload para PDF:', payload);

      await downloadPDFClient(payload);
      
      btn.textContent = "✅ PDF descargado";
      setTimeout(() => {
        btn.textContent = originalText;
        btn.disabled = false;
        btn.style.opacity = "1";
        btn.style.cursor = "pointer";
      }, 2000);
      
    } catch (err) {
      console.error("❌ Error PDF:", err);
      alert(`No se pudo generar el PDF:\n\n${err.message}\n\nRevisa la consola (F12) para más detalles.`);
      
      btn.textContent = "🖨️ Informe (PDF)";
      btn.disabled = false;
      btn.style.opacity = "1";
      btn.style.cursor = "pointer";
    }
  });
}

// -------------------
// Main
// -------------------
async function main() {
  const params = getMapainfoParamsFromUrl();

  if (isMobile()) params.n = 10;

  initMap({ lat: params.lat, lng: params.lng });

  panel = createProjectsPanel({
    containerId: "panelContent",
    countId: "panelCount",
    onSelectProject: (id) => {
      panel.highlight(id);
      mapLayers.highlightProject(id);
    },
  });

  const proyectos = await loadProyectosXlsx(DATA_XLSX_URL, "mapainfo");

  const engineOutput = runProximityEngine({
    projects: proyectos,
    center: { lat: params.lat, lng: params.lng },
    modo: params.modo,
    radioKm: params.radio,
    n: params.n,
  });

  model = buildReportModel({
    engineOutput,
    meta: { sourceXlsx: DATA_XLSX_URL, generatedAt: new Date().toISOString() },
  });

  window.__geoeva_model = model;

  renderInfoBar(model);

  const radioFinal =
    Number.isFinite(model.query.radioKmFinal) && model.query.radioKmFinal > 0
      ? model.query.radioKmFinal
      : params.radio;

  mapLayers.setQueryPoint(model.query.lat, model.query.lng);
  mapLayers.setQueryCircle(model.query.lat, model.query.lng, radioFinal);

  mapLayers.renderProjects(model.projects, {
    onMarkerClick: (id) => {
      panel.highlight(id);
      mapLayers.highlightProject(id);
    },
  });

  const bounds = typeof mapLayers.getQueryCircleBounds === "function" ? mapLayers.getQueryCircleBounds() : null;
  if (bounds) map.fitBounds(bounds, { padding: [20, 20] });
  else map.setView([model.query.lat, model.query.lng], 12);

  if (!isMobile()) panel.render(model.projects);

  if (!isMobile()) updateCharts(model);

  bindKmzButton({
    buttonId: "btnKmz",
    getModel: () => model,
    exporter: downloadProximityKMZ,
    attachGlobalName: "downloadProximityKMZ",
  });

  bindPdfButtonOnce();
}

// -------------------
// Start
// -------------------
document.addEventListener("DOMContentLoaded", () => {
  initMobileSheet();

  main().catch((err) => {
    console.error("❌ Error fatal en mapainfo.js:", err);
    alert("Error fatal. Revisa la consola.");
  });
});